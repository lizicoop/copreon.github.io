<?php

/** @var yii\web\View $this */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron text-center bg-transparent">
        <h1 class="display-4">Cotizador y presupuestador online</h1>
        <h1 class="display-4">COPREON</h1>


        <p><a class="btn btn-lg btn-success" href="http://www.yiiframework.com">Suscribirse</a></p>
    </div><br>

    <div class="body-content">

        <div class="row">
        <div class="col-lg-3"></div>
            <div class="col-lg-3">
                <h2>Contactos</h2>

                <p>Numeros de contacto</p>

            </div>

            <div class="col-lg-3">
                <h2>Redes sociales</h2>

                <ul>
                    <li>Facebook</li>
                    <li>Instagram</li>
                </ul>

            </div>

            <div class="col-lg-3"></div>
        </div>

    </div>
</div>
